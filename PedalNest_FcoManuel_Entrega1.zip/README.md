# PedalNest
Trabajo Final de Grado de DAW

Este es mí TFG del Grado Superior de DAW. Estor haciendo el dearrollo de una tienda online de bicicletas, también gestiona reservas.

Para iniciar el proyecto hay que hacer lo siguiente:
1.- Ejecutar el script de la BBDD, luego meter los inserts para que haya información como productos y algunas reseñas.
2.- En "conexión.php", poner el usuario ($dbuser) y la contraseña ($dbpass) para conectarnos a la base de datos.
3.- Yo al estar haciéndolo ahora mismo en local, lo estoy probando con XAMPP, entonces voy a la carpeta "C:\xampp\htdocs\xampp" y pongo ahí el proyecto (En mí caso tengo la carpeta PedalNest y dentro todos los archivos, en vuestro caso será PedalNest_FcoManuel_Entrega1 o PedalNest-main), ejecuto la aplicación XAMPP e inicializo MySQL y Apache. En el navegador, en mí caso, pongo la siguiente ruta: localhost/xampp/PedalNest.