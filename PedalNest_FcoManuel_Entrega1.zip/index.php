<?php 
    header('Location: back/ControladorInicio.php');
?>